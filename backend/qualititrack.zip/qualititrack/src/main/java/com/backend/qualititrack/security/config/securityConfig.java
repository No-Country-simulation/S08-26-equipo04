package com.backend.qualititrack.security.config;

import com.backend.qualititrack.utils.jwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class securityConfig {

    @Autowired
    private jwtUtils jwtUtils;

    /**
     * Configuración temporal: permite acceso a todos los endpoints
     * Una vez que UserDetailsService esté lista, descomentar autenticación completa
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(http -> {
                    // TEMPORAL: Permitir acceso a todos los endpoints de Usuario
                    http.requestMatchers("/api/usuarios/**").permitAll();
                    http.requestMatchers("/auth/**").permitAll();
                    // El resto requiere autenticación (agregar después)
                    http.anyRequest().permitAll(); // TEMPORAL: permitir todo para pruebas
                })
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}